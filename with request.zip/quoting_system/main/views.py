from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Project, ProjectElement, Material, Pricing
from .forms import UserRegisterForm






# Create your views here.


def home(request):
    return render(request, 'main/base.html')

def base(request):
    return render(request, 'main/base.html')  # Simple base dashboard template

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('base')
    else:
        form = UserRegisterForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    # Your login logic
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')  # Redirect to user dashboard
    return render(request, 'main/login.html')

@login_required
def dashboard(request):
    projects = Project.objects.filter(user=request.user)
    return render(request, 'main/dashboard.html', {'projects': projects})


@login_required
def request_quote(request):
    if request.method == 'POST':
        area_size = request.POST.get('area_size')
        project_elements = request.POST.getlist('project_elements')
        materials = request.POST.getlist('materials')

        project = Project.objects.create(
            name=f"Quotation for {request.user.username}",
            description=f"Quotation for area size: {area_size} sq.m.",
            location="User-defined location",
            status="Pending",
            user=request.user
        )

        for element_name in project_elements:
            element = ProjectElement.objects.create(project=project, name=element_name)
            for material_name in materials:
                material = Material.objects.get(name=material_name)
                Pricing.objects.create(project=project, material=material, price=material.price)

        return redirect('dashboard')

    elements = ProjectElement.objects.all()
    materials = Material.objects.all()
    return render(request, 'main/request_quote.html', {'elements': elements, 'materials': materials})