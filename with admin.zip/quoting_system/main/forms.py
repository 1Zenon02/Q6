from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm



class UserRegisterForm(UserCreationForm):
    email = forms.EmailField()
    address = forms.CharField(max_length=100)

    class Meta:
        model = User
        fields = ['username', 'email', 'address', 'password1', 'password2']



class ManagerRegistrationForm(UserCreationForm):
    id_number = forms.CharField(max_length=10, required=True, help_text="Required. Manager ID number.")

    class Meta:
        model = User
        fields = ('username', 'id_number', 'password1', 'password2')


class ManagerLoginForm(forms.Form):
    id_number = forms.CharField(max_length=10)
    password = forms.CharField(widget=forms.PasswordInput)