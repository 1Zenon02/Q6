from django.shortcuts import render, redirect
from django.shortcuts import render, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from .models import Project, ProjectElement, Material, Pricing
from .forms import UserRegisterForm
from .forms import ManagerRegistrationForm, ManagerLoginForm












# Create your views here.


def home(request):
    return render(request, 'main/base.html')

def base(request):
    return render(request, 'main/base.html')  # Simple base dashboard template

def register(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('base')
    else:
        form = UserRegisterForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    # Your login logic
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')  # Redirect to user dashboard
    return render(request, 'main/login.html')

@login_required
def dashboard(request):
    projects = Project.objects.filter(user=request.user)
    return render(request, 'main/dashboard.html', {'projects': projects})


def request_quote(request):
    if request.method == 'POST':
        area_size = request.POST.get('area_size')
        project_elements = request.POST.getlist('project_elements')
        materials = request.POST.getlist('materials')

        # Create a new project for the quote request
        project = Project.objects.create(
            name=f"Quotation for {request.user.username}",
            description=f"Quotation for area size: {area_size} sq.m.",
            location="User-defined location",
            status="Pending",
            user=request.user
        )

        # Link selected elements and materials to the project
        for element_name in project_elements:
            element = ProjectElement.objects.create(project=project, name=element_name)
            for material_name in materials:
                try:
                    material = Material.objects.get(name=material_name)
                    Pricing.objects.create(project=project, material=material, price=material.price)
                except Material.DoesNotExist:
                    pass  # Skip if material doesn't exist

        return redirect('dashboard')

    # Filter to include only specified project elements and materials
    element_names = ["Framing", "Window and Door Installation", "Electrical", "Plumbing"]
    material_names = [
        "Exterior Wall Framing", "Roof Framing", "Door Framing", "Barn Door",
        "Sliding Door", "Light Switches", "Main Panel", "Shower Fixture", "Toilet Installation"
    ]

    elements = ProjectElement.objects.filter(name__in=element_names)
    materials = Material.objects.filter(name__in=material_names)

    return render(request, 'main/request_quote.html', {'elements': elements, 'materials': materials})




@login_required
def project_detail(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    project_elements = ProjectElement.objects.filter(project=project)
    materials = []

    # Calculate total cost per material and overall project cost
    total_project_cost = 0
    for element in project_elements:
        element_materials = element.material_set.all()
        for material in element_materials:
            quantity = material.quantity
            price_per_qty = material.price_per_qty
            markup = material.markup / 100
            total_cost = quantity * price_per_qty * (1 + markup)
            total_project_cost += total_cost

            materials.append({
                'name': material.name,
                'qty': quantity,
                'unit': material.unit,
                'price_per_qty': price_per_qty,
                'total_cost': total_cost,
                'markup_percent': material.markup
            })

    context = {
        'project': project,
        'project_elements': project_elements,
        'materials': materials,
        'total_project_cost': total_project_cost
    }

    return render(request, 'main/project_detail.html', context)






# Manager Registration View
def manager_register(request):
    if request.method == 'POST':
        form = ManagerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manager_login')
    else:
        form = ManagerRegistrationForm()
    return render(request, 'manager/register.html', {'form': form})

# Manager Login View
def manager_login(request):
    if request.method == 'POST':
        form = ManagerLoginForm(request.POST)
        if form.is_valid():
            id_number = form.cleaned_data['id_number']
            password = form.cleaned_data['password']
            user = authenticate(request, username=id_number, password=password)
            if user is not None:
                login(request, user)
                return redirect('pending_dashboard')
    else:
        form = ManagerLoginForm()
    return render(request, 'manager/login.html', {'form': form})

# Pending Dashboard View for Manager
@login_required
def pending_dashboard(request):
    pending_projects = Project.objects.filter(status='Pending')
    return render(request, 'manager/pending_dashboard.html', {'pending_projects': pending_projects})



@login_required
def approved_projects(request):
    approved_projects = Project.objects.filter(status='Approved')
    return render(request, 'manager/pending_dashboard.html', {'projects': approved_projects, 'status': 'Approved'})

@login_required
def declined_projects(request):
    declined_projects = Project.objects.filter(status='Declined')
    return render(request, 'manager/pending_dashboard.html', {'projects': declined_projects, 'status': 'Declined'})

@login_required
def completed_projects(request):
    completed_projects = Project.objects.filter(status='Completed')
    return render(request, 'manager/pending_dashboard.html', {'projects': completed_projects, 'status': 'Completed'})