from django.contrib.auth.views import LogoutView
from django.urls import path
from . import views  # import views from the main app itself

urlpatterns = [
    path('', views.base, name='base'),
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('request_quote/', views.request_quote, name='request_quote'),
    path('project/<int:project_id>/', views.project_detail, name='project_detail'),
    path('manager/register/', views.manager_register, name='manager_register'),
    path('manager/login/', views.manager_login, name='manager_login'),
    path('manager/dashboard/', views.pending_dashboard, name='pending_dashboard'),
    path('manager/approved/', views.approved_projects, name='approved_projects'),
    path('manager/declined/', views.declined_projects, name='declined_projects'),
    path('manager/completed/', views.completed_projects, name='completed_projects'),







    path('logout/', LogoutView.as_view(), name='logout'),  # Logout URL
]